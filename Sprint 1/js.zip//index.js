
// Write Javascript code!
const appDiv = document.getElementById('app');
appDiv.innerHTML = `<h1>Cartão de Crédito</h1>`;

//colocar o número do cartão 
//identificar se é um array
//identificar se tem todos os 16 caracteres
//ver se são todos números *value = number*


//[i] * 2 = y 
//i+2 ao invés de i++
//depois j = 1 ; j+2
//j + y = total
//total % 10 = 0 caso contrário não é válido
//separar os elementos do array com o split()

function validNumb (numbCard){
  var doubleNumb = [];
  var singleNumb = [];
  var sumAll = doubleNumb + singleNumb;
  
  for (var i = 0 ; i < numbCard.lenght ; i+2){
    doubleNumb.push(i);
  }
  
  for (var j = 1 ; j < numbCard.lenght ; j+2){
    singleNumb.push(j);
  }
  
  


  //var rest = var sumAll % 10;
  
  if(rest = o){
    return valid;
  } else {
    return invalid;
  }
}  

/*var output = validNumb(4567345627895678);
console.log(output);*/